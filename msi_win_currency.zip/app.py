from flask import Flask, render_template, jsonify
import random

app = Flask(__name__)

# 분리수거 아이템 데이터
ITEMS = [
    {'name': '신문지', 'type': '종이'},
    {'name': '페트병', 'type': '플라스틱'},
    {'name': '비닐봉지', 'type': '비닐'},
    {'name': '캔', 'type': '캔'},
    {'name': '종이컵', 'type': '종이'},
    {'name': '플라스틱 용기', 'type': '플라스틱'},
    {'name': '알루미늄 캔', 'type': '캔'},
    {'name': '과자 봉지', 'type': '비닐'},
    {'name': '종이 상자', 'type': '종이'},
    {'name': '우유 팩', 'type': '종이'},
    {'name': '식용유 페트병', 'type': '플라스틱'},
    {'name': '스티로폼 용기', 'type': '비닐'},
    {'name': '세제 용기', 'type': '플라스틱'},
    {'name': '포장지', 'type': '종이'},
    {'name': '유리병', 'type': '캔'},
    {'name': '비닐 포장재', 'type': '비닐'},
    {'name': '페인트 통', 'type': '캔'}
]

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/get-item')
def get_item():
    if ITEMS:
        item = random.choice(ITEMS)
        ITEMS.remove(item)
        return jsonify(item)
    return jsonify({'name': None, 'type': None})

if __name__ == '__main__':
    app.run(debug=True) 